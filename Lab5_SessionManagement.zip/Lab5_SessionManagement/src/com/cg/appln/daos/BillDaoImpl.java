package com.cg.appln.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

import com.cg.appln.dto.Bill;
import com.cg.appln.exception.BillException;
import com.cg.appln.util.JndiUtil;

public class BillDaoImpl implements IBillDao {
	JndiUtil util;
	public BillDaoImpl(){
		try {
			util=new JndiUtil();
		} catch (BillException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public int insertBillDetail(Bill bill) throws BillException {
		
		int billNum=getBillNum();
		
		Connection con=null;
		PreparedStatement pst=null;
		String query="INSERT INTO BillDetails VALUES(?,?,?,?,?,sysdate)";
		
		try {
			con=util.getConnection();

			/*System.out.println(billNum);
			System.out.println();
			System.out.println(bill.getNetAmount());
			*/
			pst=con.prepareStatement(query);
			
			
			pst.setInt(1, billNum);
			pst.setInt(2, bill.getConsumer_num());
			pst.setDouble(3, bill.getCur_reading());		
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5,bill.getNetAmount());
			
			//pst.setDate(5, );
			int status= pst.executeUpdate();
			
			if(status>0){
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Error returning preparedstatement");
		}
		
		return 0;
	}

	private int getBillNum() throws BillException {
		Connection con=null;
		PreparedStatement pst=null;
		String query= "SELECT seq_bill_num.nextval FROM dual";
		ResultSet rs=null;
		int id=0;
		
		try {
			con=util.getConnection();
			pst=con.prepareStatement(query);
			rs= pst.executeQuery();
			
			if(rs.next()){
				id=rs.getInt(1);
			}
			return id;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Error while establishing connetion");
		}
	}
	
	@Override
	public String getConsumerName(int billNum) throws BillException {
		Connection con=null;
		PreparedStatement pst=null;
		String query= "SELECT consumer_name FROM Consumers WHERE consumer_num=?";
		ResultSet rs=null;
		String conName = null;
		try {
			con=util.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1, billNum);
			rs= pst.executeQuery();
			
			if(rs.next()){
				conName=rs.getString(1);				
			}
			return conName;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Error while establishing connetion");
		}
	}
	@Override
	public boolean validate(int consumerNo) throws BillException {
		Connection con=null;
		PreparedStatement pst=null;
		String query= "SELECT consumer_num FROM Consumers";
		ResultSet rs=null;
		int conNum = 0;
		try {
			con=util.getConnection();
			pst=con.prepareStatement(query);
			rs= pst.executeQuery();
			
			while(rs.next()){
				if(consumerNo==rs.getInt(1)){
					return true;
				}		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Error while establishing connetion");
		}
		return false;
	}

}
