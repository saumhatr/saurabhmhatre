package com.cg.appln.daos;

import com.cg.appln.dto.Bill;
import com.cg.appln.exception.BillException;

public interface IBillDao {
	int insertBillDetail(Bill bill)throws BillException;
	String getConsumerName(int consumerNo)throws BillException;
	boolean validate(int consumerNo)throws BillException;
}
