package com.cg.appln.dto;

public class Consumer {
	private String consumer_name;
	private int consumer_num;
	private String address;
	
	public Consumer(String consumer_name, int consumer_num, String address) {
		super();
		this.consumer_name = consumer_name;
		this.consumer_num = consumer_num;
		this.address = address;
	}

	public Consumer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getConsumer_name() {
		return consumer_name;
	}

	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}

	public int getConsumer_num() {
		return consumer_num;
	}

	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Consumer [consumer_name=" + consumer_name + ", consumer_num="
				+ consumer_num + ", address=" + address + "]";
	}	
}
