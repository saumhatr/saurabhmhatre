package com.cg.appln.service;

import com.cg.appln.dto.Bill;
import com.cg.appln.exception.BillException;

public interface IBillService {

	int insertBillDetail(Bill bill)throws BillException;
	String getConsumerName(int billNum)throws BillException;
	boolean validateCon(int consumerNo)throws BillException;
}
